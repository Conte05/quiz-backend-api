function Result({ score, onRestart }) {
    const passed = score >= 3;
    
    return (
        <main>
            <div className="result-container">
                <h1 className="result-title">
                    {passed ? 'Parabéns!' : 'Que pena!'}
                </h1>
                <p className="result-text">
                    Você acertou {score} de 5 perguntas
                </p>
                
                {passed ? (
                    <p className="result-message">
                        Você ganhou um brinde exclusivo da Funchal Negócios!
                        <br />
                        Procure nossa equipe para resgatar seu prêmio.
                    </p>
                ) : (
                    <p className="result-message">
                        Continue participando do evento!
                    </p>
                )}

                <Button text="Jogar novamente" onClick={onRestart} />
            </div>
        </main>
    );
}
