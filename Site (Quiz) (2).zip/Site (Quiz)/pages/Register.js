function Register({ onNext }) {
    const [formData, setFormData] = React.useState({
        nome: '',
        email: '',
        cargo: '',
        telefone: '',
        administradora: '',
        estado: '',
        cidade: '',
        produtos: [],
        outros: ''
    });

    const [errors, setErrors] = React.useState({
        email: '',
        telefone: '',
        cidade: ''
    });

    const validateEmail = (email) => {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    };

    const validateTelefone = (telefone) => {
        // Remove todos os caracteres não numéricos
        const numeros = telefone.replace(/\D/g, '');
        // Telefone deve ter 10 ou 11 dígitos
        return numeros.length === 10 || numeros.length === 11;
    };

    const validateCidade = (cidade) => {
        // Cidade deve ter pelo menos 2 caracteres e só letras e espaços
        return cidade.length >= 2 && /^[a-zA-ZÀ-ÿ\s]+$/.test(cidade);
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
        
        // Limpar erro quando o usuário começar a digitar
        if (errors[name]) {
            setErrors(prev => ({ ...prev, [name]: '' }));
        }
    };

    const handleCheckboxChange = (produto) => {
        setFormData(prev => {
            const produtos = prev.produtos.includes(produto)
                ? prev.produtos.filter(p => p !== produto)
                : [...prev.produtos, produto];
            return { ...prev, produtos };
        });
    };

    const handleSubmit = async () => {
        let hasErrors = false;
        let newErrors = { email: '', telefone: '', cidade: '' };

        // Validação de formato do email
        if (formData.email && !validateEmail(formData.email)) {
            newErrors.email = 'Formato de e-mail inválido. Use: exemplo@email.com';
            hasErrors = true;
        }

        // Validação de formato do telefone
        if (formData.telefone && !validateTelefone(formData.telefone)) {
            newErrors.telefone = 'Formato de telefone inválido. Use: (11) 91499-7659';
            hasErrors = true;
        }

        // Validação de formato da cidade
        if (formData.cidade && !validateCidade(formData.cidade)) {
            newErrors.cidade = 'Formato de cidade inválido. Use apenas letras';
            hasErrors = true;
        }

        // Se houver erros de formato, mostrar e não avançar
        if (hasErrors) {
            setErrors(newErrors);
            return;
        }

        // Validação completa de todos os campos obrigatórios
        if (!formData.nome || !formData.email || !formData.cargo || !formData.telefone || 
            !formData.administradora || !formData.estado || !formData.cidade) {
            alert('Por favor, preencha todos os campos obrigatórios');
            return;
        }
        
        // Validação de checkbox - pelo menos um produto deve ser selecionado
        if (formData.produtos.length === 0) {
            alert('Por favor, selecione pelo menos um produto de consórcio');
            return;
        }
        
        // Salvar no banco de dados
        try {
            const response = await fetch('/api/users', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData)
            });

            const data = await response.json();

            if (data.success) {
                // Salvar o ID do usuário para usar nas próximas etapas
                localStorage.setItem('userId', data.userId);
                onNext(formData);
            } else {
                alert('Erro ao salvar dados: ' + data.message);
            }
        } catch (error) {
            console.error('Erro ao conectar com o servidor:', error);
            alert('Erro ao conectar com o servidor. Verifique se o backend está rodando.');
        }
    };

    return (
        <main>
            <div className="register-container">
                <div className="register-section">
                    <h2 className="section-title">Dados Pessoais</h2>
                    
                    <div className="form-row">
                        <div className="form-group">
                            <label className="form-label">
                                <img src="images/Icones/Icone (Nome).png" alt="" className="label-icon" /> Nome Completo:
                            </label>
                            <input 
                                type="text"
                                name="nome"
                                placeholder="Digite seu nome completo"
                                className="form-input"
                                value={formData.nome}
                                onChange={handleInputChange}
                                required
                            />
                        </div>
                        
                        <div className="form-group">
                            <label className="form-label">
                                <img src="images/Icones/Icone (Cargo).png" alt="" className="label-icon" /> Cargo:
                            </label>
                            <input 
                                type="text"
                                name="cargo"
                                placeholder="Seu cargo atual"
                                className="form-input"
                                value={formData.cargo}
                                onChange={handleInputChange}
                                required
                            />
                        </div>
                    </div>
                    
                    <div className="form-row">
                        <div className="form-group">
                            <label className="form-label">
                                <img src="images/Icones/Icone (E-mail).png" alt="" className="label-icon" /> E-mail:
                            </label>
                            <input 
                                type="email"
                                name="email"
                                placeholder="Digite seu email"
                                className="form-input"
                                value={formData.email}
                                onChange={handleInputChange}
                                required
                            />
                            {errors.email && <span className="error-message">{errors.email}</span>}
                        </div>
                        
                        <div className="form-group">
                            <label className="form-label">
                                <img src="images/Icones/Icone (TELEFONE).png" alt="" className="label-icon" /> Telefone:
                            </label>
                            <input 
                                type="tel"
                                name="telefone"
                                placeholder="Digite seu telefone"
                                className="form-input"
                                value={formData.telefone}
                                onChange={handleInputChange}
                                required
                            />
                            {errors.telefone && <span className="error-message">{errors.telefone}</span>}
                        </div>
                    </div>
                </div>

                <div className="register-section">
                    <h2 className="section-title">Dados da sua Empresa:</h2>
                    
                    <div className="form-row">
                        <div className="form-group">
                            <label className="form-label">
                                <img src="images/Icones/Icone Administradora.png" alt="" className="label-icon" /> Administradora:
                            </label>
                            <input 
                                type="text"
                                name="administradora"
                                placeholder="Nome da sua empresa"
                                className="form-input"
                                value={formData.administradora}
                                onChange={handleInputChange}
                                required
                            />
                        </div>
                        
                        <div className="form-group">
                            <label className="form-label">
                                <img src="images/Icones/Icone (Cidade).png" alt="" className="label-icon" /> Cidade:
                            </label>
                            <input 
                                type="text"
                                name="cidade"
                                placeholder="Sua cidade"
                                className="form-input"
                                value={formData.cidade}
                                onChange={handleInputChange}
                                required
                            />
                            {errors.cidade && <span className="error-message">{errors.cidade}</span>}
                        </div>
                    </div>
                    
                    <div className="form-row">
                        <div className="form-group">
                            <label className="form-label">
                                <img src="images/Icones/Icone (Estado).png" alt="" className="label-icon" /> Estado:
                            </label>
                            <select 
                                name="estado"
                                className="form-select form-select-estado"
                                value={formData.estado}
                                onChange={handleInputChange}
                                required
                            >
                                <option value="">Selecione</option>
                                <option value="AC">Acre</option>
                                <option value="AL">Alagoas</option>
                                <option value="AP">Amapá</option>
                                <option value="AM">Amazonas</option>
                                <option value="BA">Bahia</option>
                                <option value="CE">Ceará</option>
                                <option value="DF">Distrito Federal</option>
                                <option value="ES">Espírito Santo</option>
                                <option value="GO">Goiás</option>
                                <option value="MA">Maranhão</option>
                                <option value="MT">Mato Grosso</option>
                                <option value="MS">Mato Grosso do Sul</option>
                                <option value="MG">Minas Gerais</option>
                                <option value="PA">Pará</option>
                                <option value="PB">Paraíba</option>
                                <option value="PR">Paraná</option>
                                <option value="PE">Pernambuco</option>
                                <option value="PI">Piauí</option>
                                <option value="RJ">Rio de Janeiro</option>
                                <option value="RN">Rio Grande do Norte</option>
                                <option value="RS">Rio Grande do Sul</option>
                                <option value="RO">Rondônia</option>
                                <option value="RR">Roraima</option>
                                <option value="SC">Santa Catarina</option>
                                <option value="SP">São Paulo</option>
                                <option value="SE">Sergipe</option>
                                <option value="TO">Tocantins</option>
                            </select>
                        </div>
                        
                        <div className="form-group">
                            <label className="form-label">
                                Quais produtos de consórcio a sua empresa trabalha?
                            </label>
                            <div className="checkbox-row">
                                <div className="checkbox-group">
                                    <label className="checkbox-label">
                                        <input 
                                            type="checkbox"
                                            checked={formData.produtos.includes('Veículos')}
                                            onChange={() => handleCheckboxChange('Veículos')}
                                        />
                                        <span>Veículos</span>
                                    </label>
                                    <label className="checkbox-label">
                                        <input 
                                            type="checkbox"
                                            checked={formData.produtos.includes('Imóveis')}
                                            onChange={() => handleCheckboxChange('Imóveis')}
                                        />
                                        <span>Imóveis</span>
                                    </label>
                                    <label className="checkbox-label">
                                        <input 
                                            type="checkbox"
                                            checked={formData.produtos.includes('Serviços')}
                                            onChange={() => handleCheckboxChange('Serviços')}
                                        />
                                        <span>Serviços</span>
                                    </label>
                                    <label className="checkbox-label">
                                        <input 
                                            type="checkbox"
                                            checked={formData.produtos.includes('Outros')}
                                            onChange={() => handleCheckboxChange('Outros')}
                                        />
                                        <span>Outros</span>
                                    </label>
                                </div>
                                <input 
                                    type="text"
                                    name="outros"
                                    placeholder=""
                                    className="form-input-outros"
                                    value={formData.outros}
                                    onChange={handleInputChange}
                                />
                            </div>
                        </div>
                    </div>
                </div>

                <div className="button-container">
                    <Button text="Próximo" onClick={handleSubmit} className="register-button" />
                    </div>
                </div>
        </main>
    );
}
