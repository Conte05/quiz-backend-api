function Welcome({ onStart }) {
    return (
        <main>
            <div className="welcome-text">
                <h1>Convidamos você para participar do nosso QUIZ.</h1>
                <p>
                    Acertando no mínimo três das cinco perguntas, você ganha
                    um brinde exclusivo da Funchal Negócios.
                </p>
                <p>
                    No final do evento você também irá concorrer a um sorteio
                    de <span className="highlight">10 fones de ouvido sem fio!</span>
                </p>
            </div>

            <Button text="Toque para iniciar" onClick={onStart} />
        </main>
    );
}
