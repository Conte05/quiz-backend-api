function Question({ questionData, onAnswer }) {
    return (
        <main>
            <div className="question-container">
                <h2 className="question-number">Pergunta {questionData.number} de 5</h2>
                <h1 className="question-text">{questionData.question}</h1>
                
                <div className="options-container">
                    {questionData.options.map((option, index) => (
                        <button
                            key={index}
                            className="option-button"
                            onClick={() => onAnswer(option)}
                        >
                            {option}
                        </button>
                    ))}
                </div>
            </div>
        </main>
    );
}
