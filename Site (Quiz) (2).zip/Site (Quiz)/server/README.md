# Integração com MongoDB Atlas - Guia de Configuração

## 📋 Passo a Passo

### 1. Configurar MongoDB Atlas

1. **Acesse:** https://www.mongodb.com/cloud/atlas
2. **Crie uma conta** gratuita ou faça login
3. **Crie um Cluster:**
   - Clique em "Build a Database"
   - Escolha o plano FREE (M0)
   - Selecione a região mais próxima
   - Clique em "Create"

4. **Configure o acesso:**
   - Em "Database Access", crie um usuário:
     - Username: `quizuser`
     - Password: (anote a senha)
   - Em "Network Access", adicione seu IP:
     - Clique em "Add IP Address"
     - Escolha "Allow Access from Anywhere" (0.0.0.0/0)

5. **Pegue a Connection String:**
   - Clique em "Connect" no seu cluster
   - Escolha "Connect your application"
   - Copie a string de conexão
   - Exemplo: `mongodb+srv://quizuser:<password>@cluster0.xxxxx.mongodb.net/?retryWrites=true&w=majority`

### 2. Instalar Dependências

Abra o terminal no VS Code e execute:

```bash
cd server
npm install
```

### 3. Configurar Variáveis de Ambiente

1. Copie o arquivo `.env.example` para `.env`:
   ```bash
   copy .env.example .env
   ```

2. Abra o arquivo `.env` e edite:
   ```
   MONGODB_URI=mongodb+srv://quizuser:SUA_SENHA_AQUI@cluster0.xxxxx.mongodb.net/quiz?retryWrites=true&w=majority
   PORT=3000
   ```
   
   **Substitua:**
   - `SUA_SENHA_AQUI` pela senha do usuário que você criou
   - `cluster0.xxxxx` pelo endereço do seu cluster

### 4. Iniciar o Servidor

No terminal (pasta server):

```bash
npm start
```

Ou para desenvolvimento com auto-reload:

```bash
npm run dev
```

Você verá:
```
🚀 Servidor rodando na porta 3000
✅ Conectado ao MongoDB Atlas
```

### 5. Testar

1. Inicie o Live Server do frontend
2. Preencha o formulário de registro
3. Clique em "Próximo"
4. Os dados serão salvos no MongoDB Atlas

### 6. Verificar no Atlas

1. No MongoDB Atlas, vá em "Browse Collections"
2. Você verá o database `quiz` e a collection `users`
3. Clique para ver os dados salvos

## 🔧 Estrutura de Dados

Cada usuário salvo terá:

```javascript
{
  _id: ObjectId,
  nome: String,
  email: String,
  cargo: String,
  telefone: String,
  administradora: String,
  estado: String,
  cidade: String,
  produtos: [String],
  outros: String,
  respostas: [{
    pergunta: String,
    resposta: String,
    correta: Boolean
  }],
  pontuacao: Number,
  dataRegistro: Date
}
```

## 🚨 Solução de Problemas

### Erro de conexão
- Verifique se o IP está liberado no Network Access
- Confirme se a senha está correta no `.env`
- Certifique-se de que substituiu `<password>` pela senha real

### Porta 3000 em uso
- Mude a porta no `.env`: `PORT=3001`
- Atualize também no Register.js: `http://localhost:3001/api/users`

### CORS Error
- O servidor já está configurado com CORS habilitado
- Certifique-se de que o servidor está rodando

## 📊 Próximos Passos

Para salvar também as respostas do quiz, você precisará atualizar a página de resultado para enviar os dados:

```javascript
// No componente Result
fetch(`http://localhost:3000/api/users/${userId}/respostas`, {
  method: 'PUT',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ respostas, pontuacao })
});
```
