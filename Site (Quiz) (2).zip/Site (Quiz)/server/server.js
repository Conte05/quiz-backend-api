const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');

// Configurar dotenv com caminho absoluto
require('dotenv').config({ path: path.join(__dirname, '.env') });

console.log('==========================================');
console.log('🚀 Iniciando servidor...');
console.log('📍 Diretório atual:', __dirname);
console.log('📍 NODE_ENV:', process.env.NODE_ENV || 'development');
console.log('📍 PORT:', process.env.PORT || 80);
console.log('📍 MONGODB_URI existe?', !!process.env.MONGODB_URI);
console.log('==========================================');

const app = express();

// Middlewares
console.log('✅ Configurando middlewares...');
app.use(cors());
app.use(express.json());

// Servir arquivos estáticos do frontend
console.log('✅ Configurando arquivos estáticos...');
app.use(express.static(path.join(__dirname, '..')));

// Conexão com MongoDB
console.log('🔄 Conectando ao MongoDB Atlas...');
mongoose.connect(process.env.MONGODB_URI)
.then(() => console.log('✅ Conectado ao MongoDB Atlas'))
.catch(err => {
    console.error('❌ Erro ao conectar ao MongoDB:', err.message);
    console.error('Stack:', err.stack);
});

// Schema do Usuário
console.log('✅ Criando Schema do Usuário...');
const userSchema = new mongoose.Schema({
    nome: { type: String, required: true },
    email: { type: String, required: true },
    cargo: { type: String, required: true },
    telefone: { type: String, required: true },
    administradora: { type: String, required: true },
    estado: { type: String, required: true },
    cidade: { type: String, required: true },
    produtos: [{ type: String }],
    outros: String,
    respostas: [{
        pergunta: String,
        resposta: String,
        correta: Boolean
    }],
    pontuacao: { type: Number, default: 0 },
    dataRegistro: { type: Date, default: Date.now }
});

const User = mongoose.model('User', userSchema);

// Rotas
console.log('✅ Configurando rotas da API...');
// Criar novo usuário (registro)
app.post('/api/users', async (req, res) => {
    try {
        const user = new User(req.body);
        await user.save();
        res.status(201).json({ 
            success: true, 
            userId: user._id,
            message: 'Usuário registrado com sucesso' 
        });
    } catch (error) {
        res.status(400).json({ 
            success: false, 
            message: 'Erro ao registrar usuário', 
            error: error.message 
        });
    }
});

// Atualizar respostas do quiz
app.put('/api/users/:id/respostas', async (req, res) => {
    try {
        const { respostas, pontuacao } = req.body;
        const user = await User.findByIdAndUpdate(
            req.params.id,
            { respostas, pontuacao },
            { new: true }
        );
        res.json({ 
            success: true, 
            user,
            message: 'Respostas salvas com sucesso' 
        });
    } catch (error) {
        res.status(400).json({ 
            success: false, 
            message: 'Erro ao salvar respostas', 
            error: error.message 
        });
    }
});

// Buscar todos os usuários (para relatórios)
app.get('/api/users', async (req, res) => {
    try {
        const users = await User.find().sort({ dataRegistro: -1 });
        res.json({ success: true, users });
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            message: 'Erro ao buscar usuários', 
            error: error.message 
        });
    }
});

// Buscar usuário por ID
app.get('/api/users/:id', async (req, res) => {
    try {
        const user = await User.findById(req.params.id);
        if (!user) {
            return res.status(404).json({ 
                success: false, 
                message: 'Usuário não encontrado' 
            });
        }
        res.json({ success: true, user });
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            message: 'Erro ao buscar usuário', 
            error: error.message 
        });
    }
});

// Rota para servir o index.html
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'index.html'));
});

// Iniciar servidor
const PORT = process.env.PORT || 80;
console.log('🔄 Iniciando servidor HTTP na porta', PORT);
app.listen(PORT, '0.0.0.0', () => {
    console.log('==========================================');
    console.log(`🚀 Servidor rodando na porta ${PORT}`);
    console.log(`📍 Ambiente: ${process.env.NODE_ENV || 'development'}`);
    console.log('==========================================');
}).on('error', (err) => {
    console.error('❌ Erro ao iniciar servidor:', err.message);
    console.error('Stack:', err.stack);
    process.exit(1);
});
