const questions = [
    {
        number: 1,
        question: "Qual é a pergunta número 1?",
        options: ["Opção A", "Opção B", "Opção C", "Opção D"],
        correct: "Opção A"
    },
    {
        number: 2,
        question: "Qual é a pergunta número 2?",
        options: ["Opção A", "Opção B", "Opção C", "Opção D"],
        correct: "Opção B"
    },
    {
        number: 3,
        question: "Qual é a pergunta número 3?",
        options: ["Opção A", "Opção B", "Opção C", "Opção D"],
        correct: "Opção C"
    },
    {
        number: 4,
        question: "Qual é a pergunta número 4?",
        options: ["Opção A", "Opção B", "Opção C", "Opção D"],
        correct: "Opção D"
    },
    {
        number: 5,
        question: "Qual é a pergunta número 5?",
        options: ["Opção A", "Opção B", "Opção C", "Opção D"],
        correct: "Opção A"
    }
];
