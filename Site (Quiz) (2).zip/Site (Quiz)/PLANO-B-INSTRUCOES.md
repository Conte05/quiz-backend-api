# INSTRUÇÕES - PLANO B

## 📦 O que foi criado:

### 1. **Backend (Render)** - Pasta `backend-render/`
- server.js completo
- package.json
- README com instruções

### 2. **Frontend (Discloud)** - Raiz do projeto
- Configurado como TYPE=site
- Vai apontar para o backend no Render

## 🚀 PASSO A PASSO:

### **PARTE 1: Deploy do Backend no Render**

1. Acesse: https://render.com
2. Crie uma conta (gratuita)
3. Clique em "New +" → "Web Service"
4. Escolha "Deploy from Git" ou "Deploy without Git"
   
   **Opção A - Com Git:**
   - Conecte seu GitHub
   - Crie um repositório só com a pasta `backend-render`
   - Conecte no Render

   **Opção B - Sem Git (Manual):**
   - Compacte a pasta `backend-render` em ZIP
   - Faça upload manual

5. Configure:
   - **Name:** `quiz-funchal-api`
   - **Environment:** `Node`
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Instance Type:** `Free`

6. **IMPORTANTE - Variável de Ambiente:**
   - Vá em "Environment"
   - Adicione:
     - **Key:** `MONGODB_URI`
     - **Value:** `mongodb+srv://Funchal:Funchal*123@sitefunchal.ouk1vxr.mongodb.net/quiz?appName=SiteFunchal`

7. Clique em "Create Web Service"
8. Aguarde o deploy (2-5 minutos)
9. **COPIE A URL** que o Render der (ex: `https://quiz-funchal-api.onrender.com`)

### **PARTE 2: Atualizar Frontend**

Depois de ter a URL do Render, me passe aqui que eu atualizo o `Register.js` para usar essa URL!

### **PARTE 3: Deploy do Frontend na Discloud**

1. Compacte a raiz do projeto (SEM a pasta backend-render)
2. Faça upload na Discloud normalmente
3. Pronto!

## ✅ Vantagens:

- Backend no Render: gratuito, estável, logs funcionando
- Frontend na Discloud: já configurado
- MongoDB Atlas: já funcionando
- Tudo separado e organizado

## 📞 Próximo Passo:

Faça o deploy no Render e me passe a URL!
