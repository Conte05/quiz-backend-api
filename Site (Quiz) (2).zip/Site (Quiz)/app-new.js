const { useState } = React;

function App() {
    const [currentPage, setCurrentPage] = useState('welcome'); // welcome, register, question, result
    const [currentQuestion, setCurrentQuestion] = useState(0);
    const [score, setScore] = useState(0);
    const [userData, setUserData] = useState(null);

    const handleStartQuiz = () => {
        setCurrentPage('register');
    };

    const handleRegisterComplete = (data) => {
        setUserData(data);
        setCurrentPage('question');
        setCurrentQuestion(0);
        setScore(0);
    };

    const handleAnswer = (answer) => {
        // Verifica se a resposta está correta
        if (answer === questions[currentQuestion].correct) {
            setScore(score + 1);
        }

        // Próxima pergunta ou resultado
        if (currentQuestion < questions.length - 1) {
            setCurrentQuestion(currentQuestion + 1);
        } else {
            setCurrentPage('result');
        }
    };

    const handleRestart = () => {
        setCurrentPage('welcome');
        setCurrentQuestion(0);
        setScore(0);
        setUserData(null);
    };

    return (
        <div className="container">
            <Header title={currentPage === 'register' ? 'Cadastro' : null} />
            
            {currentPage === 'welcome' && (
                <Welcome onStart={handleStartQuiz} />
            )}
            
            {currentPage === 'register' && (
                <Register onNext={handleRegisterComplete} />
            )}
            
            {currentPage === 'question' && (
                <Question 
                    questionData={questions[currentQuestion]} 
                    onAnswer={handleAnswer}
                />
            )}
            
            {currentPage === 'result' && (
                <Result 
                    score={score} 
                    onRestart={handleRestart}
                />
            )}
        </div>
    );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
