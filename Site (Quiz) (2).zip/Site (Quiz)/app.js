const { useState } = React;

function App() {
    const [quizStarted, setQuizStarted] = useState(false);

    const handleStartQuiz = () => {
        setQuizStarted(true);
        console.log('Quiz iniciado!');
        // Aqui você pode adicionar a lógica para iniciar o quiz
        // Por exemplo, navegar para a primeira pergunta
    };

    return (
        <div className="container">
            <header>
                <div className="logo-left">
                    <img src="images/Logomarca NEGATIVO PNG.png" alt="Funchal Negócios" className="logo-funchal-img" />
                    <div className="quiz-icons">
                     
                    </div>
                </div>
                <div className="logo-right">
                    <img src="images/Funchal Game Quiz - Logo 1.png" alt="Funchal Game Quiz" className="logo-img" />
                </div>
            </header>

            <main>
                <div className="welcome-text">
                    <h1>Convidamos você para participar do nosso QUIZ.</h1>
                    <p>
                        Acertando no mínimo três das cinco perguntas, você ganha <p></p>
                        um brinde exclusivo da Funchal Negócios.
                    </p>
                    <p>
                        No final do evento você também irá concorrer a um sorteio <p></p>
                        de <span className="highlight">10 fones de ouvido sem fio!</span>
                    </p>
                </div>

                <button 
                    className="start-button"
                    onClick={handleStartQuiz}
                >
                    Toque para iniciar
                </button>
            </main>
        </div>
    );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
