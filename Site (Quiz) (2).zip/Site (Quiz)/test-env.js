console.log('🔍 Teste de carregamento do dotenv');
require('dotenv').config({ path: './server/.env' });
console.log('MONGODB_URI:', process.env.MONGODB_URI ? '✅ Definido' : '❌ Não encontrado');
console.log('PORT:', process.env.PORT || 'Usando padrão (80)');
