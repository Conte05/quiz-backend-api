function Header({ title }) {
    return (
        <header>
            <div className="logo-left">
                <img src="images/Logomarca NEGATIVO PNG.png" alt="Funchal Negócios" className="logo-funchal-img" />
                <div className="quiz-icons">
                 
                </div>
            </div>
            {title && <h1 className="header-title">{title}</h1>}
            <div className="logo-right">
                <img src="images/Funchal Game Quiz - Logo 1.png" alt="Funchal Game Quiz" className="logo-img" />
            </div>
        </header>
    );
}
