function Button({ text, onClick, className = 'start-button' }) {
    return (
        <button 
            className={className}
            onClick={onClick}
        >
            {text}
        </button>
    );
}
