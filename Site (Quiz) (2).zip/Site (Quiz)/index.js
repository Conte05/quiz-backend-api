console.log('==========================================');
console.log('✅ Node.js iniciando...');
console.log('📍 Versão Node:', process.version);
console.log('📍 Diretório:', __dirname);
console.log('📍 CWD:', process.cwd());
console.log('==========================================');

// Carregar variáveis de ambiente
require('dotenv').config({ path: './server/.env' });
console.log('✅ Dotenv carregado');
console.log('📍 MONGODB_URI existe?', !!process.env.MONGODB_URI);
console.log('📍 PORT:', process.env.PORT || 80);

// Carregar dependências
console.log('⏳ Carregando Express...');
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');

console.log('✅ Dependências carregadas');

const app = express();

// Middlewares
console.log('⏳ Configurando middlewares...');
app.use(cors());
app.use(express.json());
app.use(express.static(__dirname));

console.log('✅ Middlewares configurados');

// Conectar MongoDB
console.log('⏳ Conectando ao MongoDB...');
mongoose.connect(process.env.MONGODB_URI)
.then(() => console.log('✅ MongoDB conectado!'))
.catch(err => console.error('❌ Erro MongoDB:', err.message));

// Schema
const userSchema = new mongoose.Schema({
    nome: { type: String, required: true },
    email: { type: String, required: true },
    cargo: { type: String, required: true },
    telefone: { type: String, required: true },
    administradora: { type: String, required: true },
    estado: { type: String, required: true },
    cidade: { type: String, required: true },
    produtos: [String],
    outros: String,
    respostas: [{
        pergunta: String,
        resposta: String,
        correta: Boolean
    }],
    pontuacao: { type: Number, default: 0 },
    dataRegistro: { type: Date, default: Date.now }
});

const User = mongoose.model('User', userSchema);
console.log('✅ Schema criado');

// Rotas API
app.post('/api/users', async (req, res) => {
    try {
        console.log('📨 POST /api/users - Criando usuário...');
        const user = new User(req.body);
        await user.save();
        console.log('✅ Usuário criado:', user._id);
        res.status(201).json({ 
            success: true, 
            userId: user._id,
            message: 'Usuário registrado' 
        });
    } catch (error) {
        console.error('❌ Erro ao criar usuário:', error.message);
        res.status(400).json({ 
            success: false, 
            message: error.message 
        });
    }
});

app.put('/api/users/:id/respostas', async (req, res) => {
    try {
        console.log('📨 PUT /api/users/:id/respostas');
        const { respostas, pontuacao } = req.body;
        const user = await User.findByIdAndUpdate(
            req.params.id,
            { respostas, pontuacao },
            { new: true }
        );
        res.json({ success: true, user });
    } catch (error) {
        console.error('❌ Erro:', error.message);
        res.status(400).json({ success: false, message: error.message });
    }
});

app.get('/api/users', async (req, res) => {
    try {
        const users = await User.find().sort({ dataRegistro: -1 });
        res.json({ success: true, users });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// Rota para frontend
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Iniciar servidor
const PORT = process.env.PORT || 80;
console.log('⏳ Iniciando servidor HTTP na porta', PORT);

app.listen(PORT, '0.0.0.0', () => {
    console.log('==========================================');
    console.log(`🚀 Servidor rodando em http://0.0.0.0:${PORT}`);
    console.log('==========================================');
}).on('error', (err) => {
    console.error('❌ ERRO CRÍTICO ao iniciar servidor:', err.message);
    console.error(err.stack);
    process.exit(1);
});

console.log('⏳ Servidor configurado, aguardando inicialização...');
